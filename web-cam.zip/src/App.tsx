import { useState } from 'react'
import './App.css'
import { Button, Modal } from 'react-bootstrap';
import VideoCapture from './VideoCapture';

function App() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [kitID, setKitID] = useState<string>("");
  const [CkitID, setCKitID] = useState<string>("");

  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Launch demo modal
      </Button>

      <Modal show={show} onHide={handleClose} size='lg'>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <VideoCapture onKitID={setKitID} onCKitID={setCKitID} handleClose={handleClose}></VideoCapture>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default App
