import React, { useEffect, useRef } from "react";
import { EnumCapturedResultItemType } from "dynamsoft-core";
import {
  BarcodeResultItem,
  DecodedBarcodesResult,
} from "dynamsoft-barcode-reader";
import { CameraEnhancer, CameraView } from "dynamsoft-camera-enhancer";
import {
  CapturedResultReceiver,
  CaptureVisionRouter,
} from "dynamsoft-capture-vision-router";
import { MultiFrameResultCrossFilter } from "dynamsoft-utility";
import "./cvr"; // import side effects. The license, engineResourcePath, so on.

const VideoCapture: React.FC<{
  onKitID: React.Dispatch<React.SetStateAction<string>>;
  onCKitID: React.Dispatch<React.SetStateAction<string>>;
  handleClose: () => void;
}> = ({ onKitID, onCKitID, handleClose }) => {

  const uiContainer = useRef<HTMLDivElement>(null);
  const drawingLayerContainer = useRef<HTMLDivElement>(null);

  const pInit = useRef<null | Promise<{
    cameraView: CameraView;
    cameraEnhancer: CameraEnhancer;
    router: CaptureVisionRouter;
  }>>(null);

  const init = async (): Promise<{
    cameraView: CameraView;
    cameraEnhancer: CameraEnhancer;
    router: CaptureVisionRouter;
  }> => {
    try {
      const drwLayerId = drawingLayerContainer.current;
      const cameraView = await CameraView.createInstance();
      const cameraEnhancer = await CameraEnhancer.createInstance(cameraView);
      uiContainer.current!.innerText = "";
      uiContainer.current!.append(cameraView.getUIElement());

      // Set the default style for a selected rectangle
      const drawingLayerId = 102; // Replace with the correct drawingLayerId (should be a number)
      const drawingLayer = cameraView.getDrawingLayer(drawingLayerId);
      
      // Check if drawingLayer is not null before setting the default style
      if (drawingLayer) {
        // drawingLayer.setDefaultStyle("selected", "rect");
      }

      const router = await CaptureVisionRouter.createInstance();
      router.setInput(cameraEnhancer);
      
      const resultReceiver = new CapturedResultReceiver();
      resultReceiver.onDecodedBarcodesReceived = (
        result: DecodedBarcodesResult
      ) => {
        if (!result.barcodeResultItems.length) return;

        const code39Results = result.barcodeResultItems.filter(
          (item: BarcodeResultItem) => item.formatString === "CODE_128"
        );

        if (code39Results.length > 0) {
          onKitID(code39Results[0].text);
          onCKitID(code39Results[0].text);
          handleClose();
        }
      };
      router.addResultReceiver(resultReceiver);

      const filter = new MultiFrameResultCrossFilter();
      filter.enableResultCrossVerification(
        EnumCapturedResultItemType.CRIT_BARCODE,
        true
      );
      filter.enableResultDeduplication(
        EnumCapturedResultItemType.CRIT_BARCODE,
        true
      );
      filter.setDuplicateForgetTime(
        EnumCapturedResultItemType.CRIT_BARCODE,
        3000
      );
      await router.addResultFilter(filter);

      await cameraEnhancer.open();
      await router.startCapturing("ReadSingleBarcode");

      return {
        cameraView,
        cameraEnhancer,
        router,
      };
    } catch (ex: any) {
      console.error(ex.message || ex);
      throw ex;
    }
  };

  const destroy = async (): Promise<void> => {
    try {
      if (pInit.current) {
        const { cameraView, cameraEnhancer, router } = await pInit.current;
        await router.dispose();
        await cameraEnhancer.dispose();
        await cameraView.dispose();
      }
    } catch (ex) {
      console.error(ex);
      throw ex;
    }
  };

  useEffect(() => {
    let isMounted = true;

    const initializeCamera = async () => {
      try {
        const instance = await init();
        if (isMounted) {
          pInit.current = Promise.resolve(instance);
        }
      } catch (error) {
        console.error("Error initializing camera:", error);
      }
    };

    document.querySelector(".dce-sel-camera")?.remove();

    initializeCamera();

    return () => {
      isMounted = false;
      if (pInit.current) {
        pInit.current
          .then(async ({ cameraView, cameraEnhancer, router }) => {
            await router.dispose();
            await cameraEnhancer.dispose();
            await cameraView.dispose();
            console.log("VideoCapture Component Unmount");
          })
          .catch((error) => {
            console.error("Error cleaning up camera:", error);
          });
      }
    };
  }, []);

  return (
    <>
      <div
        ref={uiContainer}
        className="div-ui-container"
        style={{
          width:  "700px",
          height: "400px",
          position: "relative", // Add this line to make the child positioning absolute
        }}
      >
        {/* You can add any additional content or components here */}
      </div>
      <div id="drw-layer" ref={drawingLayerContainer}></div>
    </>
  );
};

export default VideoCapture;
